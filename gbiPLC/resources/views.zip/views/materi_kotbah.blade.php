<x-nav-bar/>
<x-layout>
    @livewire('materi-kotbah-user')
</x-layout>

